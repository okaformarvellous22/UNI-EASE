
# Campus Assist — Working MVP

This is the first real working MVP of Campus Assist.

## Included
- Customer signup/login
- Worker login/dashboard
- Admin login/control center
- SQLite database (real persistent database)
- Orders and order history
- Worker acceptance and status updates
- Admin worker assignment
- Complaints
- Ratings/feedback
- Order event/status history
- Basic revenue/order statistics
- Mobile-friendly interface
- PWA manifest

## Demo accounts
Customer:
customer@campusassist.local
customer123

Worker:
worker@campusassist.local
worker123

Admin:
admin@campusassist.local
admin123

## Run
Requires Node.js 22+.

```bash
node server.js
```

Then open:
http://localhost:3000

The database is created automatically as `campus-assist.sqlite`.

## Important
This is a functioning MVP, but it is not yet a public production deployment. For real customers on different phones, the Node server and SQLite database need to be deployed on a server with persistent storage, or the database can be moved to Supabase/Postgres.

The previous Campus Assist architecture targeted Supabase for the shared production backend. This MVP keeps the same customer/worker/admin flow so the production backend can be connected without redesigning the product.
